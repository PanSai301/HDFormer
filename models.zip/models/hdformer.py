"""Unified HDformer model architecture for pretraining and finetuning."""
import torch
import torch.nn as nn
from einops import rearrange
from transformers import BertConfig
from transformers import GPT2Model, BertModel
from transformers.models.bert.modeling_bert import BertEncoder

class GradientReversalFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambda_):
        ctx.lambda_ = lambda_
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        output = grad_output.neg() * ctx.lambda_
        return output, None
        
class GradientReversalLayer(nn.Module):
    def __init__(self, lambda_=1.0):
        super(GradientReversalLayer, self).__init__()
        self.lambda_ = lambda_

    def forward(self, x):
        return GradientReversalFunction.apply(x, self.lambda_)
        
class DomainDiscriminator(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.output_dim = config['output_dim']
        self.proj_dim = config['proj_dim']
        self.grl = GradientReversalLayer()
        self.fc = nn.Sequential(
            nn.Linear(self.output_dim, self.proj_dim),
            nn.ReLU(),
            nn.Linear(self.proj_dim, 4)
        )
    def forward(self, x):
        x = self.grl(x)
        x = self.fc(x)
        return x

class HDEmbedding(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Ensure transformer dict exists
        if 'transformer' not in config:
            config['transformer'] = {}
            
        self.n_cat = config.get('n_category_feats', 17)
        self.n_float = config.get('n_float_feats', 41)
        self.n_cat_val = config.get('n_category_values', 500)
        self.n_float_val = config.get('n_float_values', 256)
        
        self.register_buffer(
            "token_type_ids", torch.arange(self.n_cat + self.n_float + 1), persistent=False
        )
        self.register_buffer(
            "one", torch.ones(1, dtype=torch.long), persistent=False
        )
        self.register_buffer(
            "zero", torch.zeros(1, dtype=torch.long), persistent=False
        )

        hidden_size = config['transformer'].get('hidden_size', 256)
        num_heads = min(8, hidden_size // 32) if hidden_size >= 32 else 1
        num_heads = max(1, num_heads)
        
        self.bert = BertModel(BertConfig(
            vocab_size=self.n_cat_val + self.n_float_val + 2, 
            hidden_size=hidden_size,
            num_hidden_layers=1,
            num_attention_heads=num_heads,
            intermediate_size=hidden_size * 4,
            hidden_act="gelu",
            hidden_dropout_prob=0.1,
            attention_probs_dropout_prob=0.1,
            max_position_embeddings=8192,
            type_vocab_size=self.n_cat + self.n_float + 1,
            initializer_range=0.02,
            layer_norm_eps=1e-12,
            pad_token_id=1,
            position_embedding_type="none",
            use_cache=True,
            classifier_dropout=None,
            _attn_implementation="eager",
        ))

    def forward(self, cat_feats, float_feats): 
        B = cat_feats.shape[0]
        L = cat_feats.shape[2]
        cat_feats_mask = cat_feats == -1
        float_feats_mask = float_feats == -1
        attention_mask = torch.cat([self.one.unsqueeze(1).unsqueeze(0).expand(B, -1, L), ~cat_feats_mask, ~float_feats_mask], dim=1)
        attention_mask = rearrange(attention_mask, 'b n l -> (b l) n')

        cat_feats = cat_feats + 2
        cat_feats[cat_feats_mask] = 1
        float_feats = float_feats + 2 + self.n_cat_val
        float_feats[float_feats_mask] = 1
        input_ids = torch.cat([self.zero.unsqueeze(1).unsqueeze(0).expand(B, -1, L), cat_feats.long(), float_feats.long()], dim=1)
        input_ids = rearrange(input_ids, 'b n l -> (b l) n')

        BL = input_ids.shape[0]
        token_type_ids = self.token_type_ids.unsqueeze(0).expand(BL, -1)
        ft_emb = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids
        ).pooler_output
        ft_emb = rearrange(ft_emb, '(b l) d -> b l d', b=B)
        return ft_emb 

class MultiTaskHeadPretrain(nn.Module):
    """Pretraining head for feature-level masked prediction."""
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.output_dim = config['transformer'].get('hidden_size', 256)
        self.n_category_feats = config.get('n_category_feats', 17)
        self.n_float_feats = config.get('n_float_feats', 41)
        
        cat_vocab_sizes = config.get('cat_vocab_sizes', [])
        if len(cat_vocab_sizes) != self.n_category_feats:
            cat_vocab_sizes = [config.get('n_category_values', 500) + 2] * self.n_category_feats
        
        self.cls_heads = nn.ModuleList([
            nn.Sequential(
                nn.Linear(self.output_dim, 256),
                nn.ReLU(),
                nn.Linear(256, vocab_size) 
            ) for vocab_size in cat_vocab_sizes
        ])
        
        self.reg_heads = nn.ModuleList([
            nn.Sequential(
                nn.Linear(self.output_dim, 256),
                nn.ReLU(),
                nn.Linear(256, 256)
            ) for _ in range(self.n_float_feats)
        ])

    def forward(self, hidden_states, cat_feats, float_feats, valid_mask):
        B, L, D = hidden_states.shape
        
        cls_predictions = []
        for i, cls_head in enumerate(self.cls_heads):
            pred = cls_head(hidden_states)
            cls_predictions.append(pred)
        
        reg_predictions = []
        for i, reg_head in enumerate(self.reg_heads):
            pred = reg_head(hidden_states)
            reg_predictions.append(pred)
            
        return cls_predictions, reg_predictions

class MultiTaskHeadFinetune(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.output_dim = config['transformer'].get('hidden_size', 256)
        self.n_cls = self.config.get('n_cls', [2])

        self.cls_fcs = nn.ModuleList(nn.Sequential(
            nn.Linear(self.output_dim, 256),
            nn.ReLU(),
            nn.Linear(256, n)
        ) for n in self.n_cls)

    def forward(self, x, B):
        results = []
        for i, cls_fc in enumerate(self.cls_fcs):
            y_cls = cls_fc(x)
            y_cls = rearrange(y_cls, '(b l) d -> b l d', b=B)
            results.append(y_cls)
        return results

class HDFormer(nn.Module):
    """Unified HDFormer model for both pretraining and finetuning."""
    def __init__(self, config):
        super().__init__()
        self.config = config 
        self.mode = config.get('mode', 'finetune')
        
        # Make sure transformer config is a dict
        if 'transformer' not in config:
            config['transformer'] = {}
        
        hidden_size = config['transformer'].get('hidden_size', 256)
        num_heads = min(8, hidden_size // 32) if hidden_size >= 32 else 1
        num_heads = max(1, num_heads)
        
        self.bert_config = BertConfig(
            vocab_size=config['n_category_values'] + config['n_float_values'] + 2,
            hidden_size=hidden_size,
            num_hidden_layers=2,
            num_attention_heads=num_heads,
            intermediate_size=hidden_size * 4,
            hidden_act="gelu",
            hidden_dropout_prob=0.1,
            attention_probs_dropout_prob=0.1,
            max_position_embeddings=8192,
            type_vocab_size=config['n_category_feats'] + config['n_float_feats'] + 1,
            initializer_range=0.02,
            layer_norm_eps=1e-12,
            pad_token_id=1,
            position_embedding_type="none",
            use_cache=True,
            classifier_dropout=None,
            _attn_implementation="eager",
        )
        
        self.hd_embed = HDEmbedding(config)
        
        # We assume the config passes standard GPT2Config parameters nested in 'transformer'
        from transformers import GPT2Config
        gpt2_config = GPT2Config(
            vocab_size=1,
            n_positions=config.get('seq_max_len', 32),
            n_embd=hidden_size,
            n_layer=config['transformer'].get('num_hidden_layers', 4),
            n_head=num_heads,
            n_inner=config['transformer'].get('n_inner', 1024),
            resid_pdrop=config['transformer'].get('resid_pdrop', 0.1),
            embd_pdrop=config['transformer'].get('embd_pdrop', 0.1),
            attn_pdrop=config['transformer'].get('attn_pdrop', 0.1)
        )
        self.transformer = GPT2Model(gpt2_config)
        
        self.mu_head = nn.Linear(hidden_size, config.get('vae_bottleneck_dim', 64))
        self.logvar_head = nn.Linear(hidden_size, config.get('vae_bottleneck_dim', 64))
        self.decoder_proj = nn.Linear(config.get('vae_bottleneck_dim', 64), hidden_size)
        self.decoder = BertEncoder(self.bert_config)
        
        if self.mode == 'finetune':
            self.head = MultiTaskHeadFinetune(config)
        else:
            self.pretrain_head = MultiTaskHeadPretrain(config)
    
    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, cat_feats, float_feats, valid_mask, time_index, **kwargs):
        B = cat_feats.shape[0]
        ft_emb = self.hd_embed(cat_feats, float_feats)
        
        y = self.transformer(
            inputs_embeds=ft_emb,
            position_ids=time_index,
            attention_mask=valid_mask
        ).last_hidden_state
        
        mu = self.mu_head(y)
        logvar_raw = self.logvar_head(y)
        
        z = self.reparameterize(mu, logvar_raw)
        decoded = self.decoder_proj(z)
        
        # (This is just a skeleton of forward pass matching PANS structure)
        return mu, logvar_raw, decoded
